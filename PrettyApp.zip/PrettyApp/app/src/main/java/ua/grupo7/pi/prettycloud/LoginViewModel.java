package ua.grupo7.pi.prettycloud;

import android.arch.lifecycle.ViewModel;

public class LoginViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
