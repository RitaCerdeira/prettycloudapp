package ua.grupo7.pi.prettycloud;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import java.util.List;

import retrofit2.Call;
import ua.grupo7.pi.prettycloud.communication.PrettyCloudWebService;
import ua.grupo7.pi.prettycloud.models.Salon;
import ua.grupo7.pi.prettycloud.models.User;

public class SalonViewModel extends ViewModel {
    // TODO: Implement the ViewModel
    private MutableLiveData<List<Salon>> salonList;
    private PrettyCloudWebService webService;
    public LiveData<List<Salon>> getSalons() {
        if (salonList == null){
            salonList = new MutableLiveData<>();
            loadSalons();
        }
        return salonList;
    }

    private void loadSalons() {
        salonList = (MutableLiveData<List<Salon>>) webService.getSalons();
    }
}
