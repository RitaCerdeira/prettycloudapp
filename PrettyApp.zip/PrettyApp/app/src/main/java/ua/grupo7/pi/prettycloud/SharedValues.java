package ua.grupo7.pi.prettycloud;

public class SharedValues {

    public String isLoggedIn = "IS_LOOGED_IN";
    public String ErrorMessage = "ERROR_MESSAGE";
    public String API_TOKEN = "API_TOKEN";
}
