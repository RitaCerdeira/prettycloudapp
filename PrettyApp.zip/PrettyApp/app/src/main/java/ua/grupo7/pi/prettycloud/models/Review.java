package ua.grupo7.pi.prettycloud.models;

public class Review {

    private int idSalon;

    private Rating rating;

    private String comment;

}
