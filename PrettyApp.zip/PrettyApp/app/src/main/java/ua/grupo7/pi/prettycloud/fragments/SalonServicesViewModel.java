package ua.grupo7.pi.prettycloud.fragments;

import androidx.lifecycle.ViewModel;

public class SalonServicesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
