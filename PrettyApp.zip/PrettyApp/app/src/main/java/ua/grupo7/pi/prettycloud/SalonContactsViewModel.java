package ua.grupo7.pi.prettycloud;

import androidx.lifecycle.ViewModel;

public class SalonContactsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
